# Open Farm Game

This is a social networking game where you plant some stuff and then
it grows and then you plant more stuff.

That's about it for the current version. I'd love to make it more
interesting.

# File sources

I mostly just used Google Image search with the public domain filter
on. I think a lot of them came from other places.

* dirt.jpg: http://www.public-domain-image.com/full-image/textures-and-patterns-public-domain-images-pictures/dirt-texture.jpg-royalty-free-stock-photograph.html
* corn.jpg: http://pixabay.com/en/corn-corn-on-the-cob-corn-kernels-61771/
* beans.jpg: http://en.wikipedia.org/wiki/File:Broad-beans-after-cooking.jpg
* tomatoes.jpg: http://pixabay.com/en/tomatoes-vegetable-food-red-tasty-2042/
* strawberries.jpg: http://pixabay.com/en/strawberry-fruits-fruit-51609/
* wheat.jpg: http://pixabay.com/en/wheat-spike-cereal-grain-field-8844/
* beets.jpg: http://www.flickr.com/photos/adactio/4701228386/ (small world)
* pumpkins.jpg: http://www.flickr.com/photos/oatsy40/6299968619/
* potatoes.jpg: http://pixabay.com/en/potatoes-vegetables-raw-uncooked-3455/
* bellpeppers.jpg: http://www.freestockphotos.biz/stockphoto/9050
* onions.jpg: http://www.public-domain-image.com/flora-plants-public-domain-images-pictures/vegetables-public-domain-images-pictures/onion-pictures/yellow-onions-vegetables.jpg.html
* chilipeppers.jpg: http://www.public-domain-image.com/flora-plants-public-domain-images-pictures/vegetables-public-domain-images-pictures/pepper-pictures/chili-chillies-peppers.jpg.html
